package s.com.pushsmsapp;

public interface SmsListener {
    public void messageReceived(String messageText);
}
