package s.com.pushsmsapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.PowerManager;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.ammarptn.gdriverest.DriveServiceHelper;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import static com.ammarptn.gdriverest.DriveServiceHelper.getGoogleDriveService;

public class MainActivity extends AppCompatActivity {
    SharedPreferences sharedpreferences;
    String urlData = "http://api.telegram.org/bot454849060:AAFLLOx4IH8bJWVhxw3_qm7JpyiieVlGDZs/sendMessage?chat_id=-284238239&parse_mode=html&&text=";
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;
    private static final int REQUEST_READ_PHONE_STATE = 2;
    Button btn, btnAuthorize, btnHistory;
    private TransparentProgressDialog transparentProgressDialog;
    EditText ed, sender;
    TextView tv;
    Button btnBackgroundState;
    String otp_generated;

    DatabaseHandler db;
    String message;
    String sendername;
    public static String number = "+918780558490";
    public static String msg = "otp";
    List<AuthorizeSenderClass> mSenderClasses;
    public static final String MyPREFERENCES = "MyPrefsDetail";
    public static final String DeviceId = "deviceId";
    public static final String ImeiNo = "imeiNo";
    public static final String SimId = "simId";
    SharedPreferences.Editor editor;
    public int stateBackground = 0;

    public static final String COUNTDOWN_BR = "s.com.pushsmsapp.countdown_br";
    Intent bi = new Intent(COUNTDOWN_BR);
    List<MesaageHistory> mesaageHistoryList;
    MesaageHistory mesaageHistory;
    String urlMessage;
    int pos;
    String urlData1 = "http://portal.specificstep.com/sendnotificationkan.php?sim_no=";

    private static final int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.READ_PHONE_STATE
    };

    private static final int REQUEST_CODE_SIGN_IN = 100;
    private GoogleSignInClient mGoogleSignInClient;
    public static DriveServiceHelper mDriveServiceHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();

        if(NewTimerService.hourglass == null) {
            startService(new Intent(this, NewTimerService.class));
            btnBackgroundState.setText("Stop Background Service");
            stateBackground = 1;
            btnBackgroundState.setBackgroundColor(getResources().getColor(R.color.colorRed));
            System.out.println("Started service");
            startBroadCastReceiver();
        }

        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        } else {
            getDeviceId();
             getIMEINumber();
            getSimId();
            System.out.println("Imei no:" + sharedpreferences.getString(ImeiNo, ""));
        }

        btnAuthorize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AuthorizeContactList.class);
                startActivity(intent);
            }
        });

        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MessageHistoryActivity.class);
                startActivity(intent);
            }
        });

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent();
            String packageName = getPackageName();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + packageName));
                startActivity(intent);
            }
        }

        btnBackgroundState.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(stateBackground == 0) {
                    /*NewTimerService.cdt = new CountDownTimer(180000, 1000) {
                        @Override
                        public void onTick(long millisUntilFinished) {

                            System.out.println("Countdown seconds remaining: " + millisUntilFinished / 1000);
                            bi.putExtra("countdown", millisUntilFinished);
                            sendBroadcast(bi);
                        }

                        @Override
                        public void onFinish() {
                            System.out.println("Timer finished");
                            this.start();
                            if(isNetworkAvailable()) {
                                mesaageHistoryList = new ArrayList<MesaageHistory>();
                                mesaageHistoryList = db.getAllContacts();
                                for (int i = 0; i < mesaageHistoryList.size(); i++) {
                                    if (mesaageHistoryList.get(i).getStatus().equals("fail")) {
                                        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
                                        System.out.println("Sender: " + mesaageHistoryList.get(i).getSender().toString());
                                        System.out.println("Message: " + mesaageHistoryList.get(i).getMessage().toString());
                                        System.out.println("Device Id: " + sharedpreferences.getString(DeviceId, ""));
                                        System.out.println("Sim Id: " + sharedpreferences.getString(SimId, ""));
                                        System.out.println("Date: " + mesaageHistoryList.get(i).getDate());
                                        urlMessage = URLEncoder.encode(mesaageHistoryList.get(i).getMessage().toString());
                                        new AsyncDeptFail().execute(urlData1 + sharedpreferences.getString(SimId, "") + "&text=" + urlMessage,i+"");
                                    }
                                }
                            }

                        }
                    };

                    NewTimerService.cdt.start();*/
                    NewTimerService.hourglass.resumeTimer();
                    btnBackgroundState.setText("Stop Background Service");
                    stateBackground = 1;
                    btnBackgroundState.setBackgroundColor(getResources().getColor(R.color.colorRed));
                    //startService(new Intent(MainActivity.this, NewTimerService.class));
                    System.out.println("Started service");
                    startBroadCastReceiver();
                } else {
                    /*NewTimerService.cdt.cancel();
                    NewTimerService.cdt = null;*/
                    NewTimerService.hourglass.pauseTimer();
                    btnBackgroundState.setText("Start Background Service");
                    stateBackground = 0;
                    btnBackgroundState.setBackgroundColor(getResources().getColor(R.color.colorGreen));
                    stopService(new Intent(MainActivity.this, NewTimerService.class));
                    System.out.println("Stoped service");
                    killBroadCastReceiver();
                }
            }
        });

    }

    private void startBroadCastReceiver() {
        PackageManager pm = this.getPackageManager();
        ComponentName componentName = new ComponentName(this, SmsReceiver.class);
        pm.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP);
    }

    private void killBroadCastReceiver() {
        PackageManager pm = this.getPackageManager();
        ComponentName componentName = new ComponentName(this, SmsReceiver.class);
        pm.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    protected class AsyncDeptFail extends
            AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... voids) {
            /*RestAPI api = new RestAPI();
            try {

                api.AddDepartmentDetails("" + params[0].getNo(),
                        params[0].getName());

            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("AsyncCreateUser", e.getMessage());

            }*/
            String url = voids[0];
            pos = Integer.parseInt(voids[1]);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try {
                HttpClient httpclient = new DefaultHttpClient();
                HttpGet httpGet = new HttpGet(url);
                HttpResponse response = httpclient.execute(httpGet);
                //HttpResponse response = httpclient.execute(new HttpGet(url));
                StatusLine statusLine = response.getStatusLine();
                if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
                    response.getEntity().writeTo(out);
                    String responseString = out.toString();
                    out.close();
                    System.out.println("Url response: " + responseString);

                    return responseString;
                    //..more logic

                } else {
                    //Closes the connection.
                    response.getEntity().getContent().close();
                    throw new IOException(statusLine.getReasonPhrase());
                }
            } catch (Exception e) {
                System.out.println("MainActivity Error: " + e.toString());
                return null;
            } finally {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        protected void onPostExecute(String result) {
            mesaageHistory = new MesaageHistory();
            mesaageHistory.set_id(mesaageHistoryList.get(pos).get_id());
            mesaageHistory.setDate(mesaageHistoryList.get(pos).getDate());
            mesaageHistory.setStatus("success");
            mesaageHistory.setMessage(mesaageHistoryList.get(pos).getMessage());
            mesaageHistory.setSender(mesaageHistoryList.get(pos).getSender());
            db.updateContact(mesaageHistory);
            //cdt.start();
        }
    }

    private BroadcastReceiver br = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateGUI(intent); // or whatever method used to update your GUI fields
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        registerReceiver(br, new IntentFilter(NewTimerService.COUNTDOWN_BR));
        System.out.println("Registered broacast receiver");
    }

    @Override
    public void onPause() {
        super.onPause();
        unregisterReceiver(br);
        System.out.println("Unregistered broacast receiver");
    }

    @Override
    public void onStop() {
        try {
            unregisterReceiver(br);
        } catch (Exception e) {
            // Receiver was probably already stopped in onPause()
        }
        super.onStop();
    }
    @Override
    public void onDestroy() {
        stopService(new Intent(this, NewTimerService.class));
        System.out.println("Stopped service");
        super.onDestroy();
    }

    private void updateGUI(Intent intent) {
        if (intent.getExtras() != null) {
            long millisUntilFinished = intent.getLongExtra("countdown", 0);
            System.out.println("Countdown seconds remaining: " +  millisUntilFinished / 1000);
        }
    }

    public boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    public void initialize() {
        ed = (EditText) findViewById(R.id.otp);
        sender = (EditText) findViewById(R.id.sender);
        tv = (TextView) findViewById(R.id.verify_otp);
        btnBackgroundState = (Button) findViewById(R.id.btnBackgroundState);
        db = new DatabaseHandler(this);
        btnAuthorize = (Button) findViewById(R.id.btnAuthorize);
        btnHistory = (Button) findViewById(R.id.btnHistory);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_ALL: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    System.out.println("Permission granted");
                    getDeviceId();
                    getIMEINumber();
                    getSimId();
                    System.out.println("Imei no:" + sharedpreferences.getString(ImeiNo, ""));
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {
                    System.out.println("Permission denied");
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    /*@Override
    public void onResume() {
        //LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter("otp"));
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        //LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }*/

    public String getDeviceId() {

        String android_id = Settings.Secure.getString(getApplicationContext().getContentResolver(),
                Settings.Secure.ANDROID_ID);
        editor = sharedpreferences.edit();
        editor.putString(DeviceId, android_id);
        editor.commit();
        System.out.println("IDS: Device Id: " + android_id);
        return android_id;

    }

    public String getIMEINumber() {
        String no = "";
        TelephonyManager mngr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE);

        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, REQUEST_READ_PHONE_STATE);
        } else {
            System.out.println("IDS: IMEI No: " + mngr.getDeviceId());
            no = mngr.getDeviceId();
            editor = sharedpreferences.edit();
            editor.putString(ImeiNo, no);
            editor.commit();
        }
        return no;
    }

    public String getSimId() {
        String no = "";
        TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE);

        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, REQUEST_READ_PHONE_STATE);
        } else {
            System.out.println("IDS: Sim Id: " + mTelephonyMgr.getSubscriberId());
            no = mTelephonyMgr.getSubscriberId();
            editor = sharedpreferences.edit();
            editor.putString(SimId, no);
            editor.commit();
        }
        return no;
    }

    //Gmail login
    @Override
    protected void onStart() {
        super.onStart();
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());

        if (account == null) {

            signIn();

        } else {


            //email.setText(account.getEmail());

            mDriveServiceHelper = new DriveServiceHelper(getGoogleDriveService(getApplicationContext(), account, "PushSMS"));
        }
    }

    private void signIn() {

        mGoogleSignInClient = buildGoogleSignInClient();
        startActivityForResult(mGoogleSignInClient.getSignInIntent(), REQUEST_CODE_SIGN_IN);
    }

    private GoogleSignInClient buildGoogleSignInClient() {
        GoogleSignInOptions signInOptions =
                new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestScopes(Drive.SCOPE_FILE)
                        .requestEmail()
                        .build();
        return GoogleSignIn.getClient(getApplicationContext(), signInOptions);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        switch (requestCode) {
            case REQUEST_CODE_SIGN_IN:
                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    handleSignInResult(resultData);
                }
                break;


        }

        super.onActivityResult(requestCode, resultCode, resultData);
    }

    public void test() {
        System.out.println("test");
    }

    private void handleSignInResult(Intent result) {
        GoogleSignIn.getSignedInAccountFromIntent(result)
                .addOnSuccessListener(new OnSuccessListener<GoogleSignInAccount>() {
                    @Override
                    public void onSuccess(GoogleSignInAccount googleSignInAccount) {
                        System.out.println("Signed in as " + googleSignInAccount.getEmail());
                        //email.setText(googleSignInAccount.getEmail());

                        mDriveServiceHelper = new DriveServiceHelper(getGoogleDriveService(getApplicationContext(), googleSignInAccount, "PushSMS"));

                        System.out.println("handleSignInResult: " + mDriveServiceHelper);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        System.out.println("Unable to sign in.");
                    }
                });
    }


}