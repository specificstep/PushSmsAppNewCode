package s.com.pushsmsapp;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.text.TextUtils;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SmsReceiver extends BroadcastReceiver {

    private static SmsListener mListener;
    List<AuthorizeSenderClass> mSenderClasses;
    DatabaseHandler db;
    String sender, messageBody;
    long dateTime;
    Context mContext;
    private static final int REQUEST_READ_PHONE_STATE = 2;
    public static final String MyPREFERENCES = "MyPrefsDetail" ;
    public static final String DeviceId = "deviceId";
    public static final String ImeiNo = "imeiNo";
    public static final String SimId = "simId";
    SharedPreferences sharedpreferences;
    String urlMessage;
    String messageDate;

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle data  = intent.getExtras();
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        mContext = context;
        if(data != null) {
            System.out.println("Background app working fine");
            Object[] pdus = (Object[]) data.get("pdus");

            if(pdus != null) {
                for (int i = 0; i < pdus.length; i++) {
                    SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) pdus[i]);

                    sender = smsMessage.getDisplayOriginatingAddress();

                    //You must check here if the sender is your provider and not another one with same text.

                    messageBody = smsMessage.getMessageBody();
                    dateTime = smsMessage.getTimestampMillis();

                    Calendar sendTime = Calendar.getInstance();
                    sendTime.setTimeInMillis(dateTime);

                    messageDate = sendTime.get(Calendar.DATE) + "-" +
                            (sendTime.get(Calendar.MONTH) + 1) + "-" + sendTime.get(Calendar.YEAR) +
                            " " + sendTime.get(Calendar.HOUR_OF_DAY) + ":" + sendTime.get(Calendar.MINUTE) +
                            ":" + sendTime.get(Calendar.SECOND);
                    System.out.println("Message Date: " + messageDate);

                    //pass in message body
                    urlMessage = URLEncoder.encode("Sender: " + sender + "\n\n" + messageBody + "\n\n" + "Device Id: " + sharedpreferences.getString(DeviceId, "") + "\n" + "Sim Id: " + sharedpreferences.getString(SimId, "") + "\n" + "Date: " + messageDate);

                    mSenderClasses = new ArrayList<AuthorizeSenderClass>();
                    db = new DatabaseHandler(context);
                    mSenderClasses = db.getAllAuthContacts();

                    for (int j = 0; j < mSenderClasses.size(); j++) {
                        if(!TextUtils.isEmpty(mSenderClasses.get(j).getAuthmessage())) {
                            if (sender.toLowerCase().contains(mSenderClasses.get(j).getAuthsender().toLowerCase()) && messageBody.toLowerCase().contains(mSenderClasses.get(j).getAuthmessage().toLowerCase())) {
                                db.addContact(new MesaageHistory(sender, urlMessage, "fail", messageDate));
                            } else {
                                System.out.println("SMS RECEIVER: Sender is not exist in Authorize contacts list");
                            }
                        } else if(sender.toLowerCase().contains(mSenderClasses.get(j).getAuthsender().toLowerCase())) {
                            db.addContact(new MesaageHistory(sender, urlMessage, "fail", messageDate));
                        }
                    }

            /*if(sender.equals(MainActivity.number)) {

                if (messageBody.contains(MainActivity.msg)) {
                    //Pass on the text to our listener.
                    Intent myIntent = new Intent("otp");
                    myIntent.putExtra("message", messageBody);
                    myIntent.putExtra("sender", sender);
                    LocalBroadcastManager.getInstance(context).sendBroadcast(myIntent);
                }

            }*/
                    //mListener.messageReceived(messageBody);
                }
            }
        } else {
            System.out.println("Background app working not fine");
        }

    }

}


