package s.com.pushsmsapp;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gdata.client.contacts.ContactsService;
import com.google.gdata.data.PlainTextConstruct;
import com.google.gdata.data.contacts.ContactEntry;
import com.google.gdata.data.contacts.ContactFeed;
import com.google.gdata.data.extensions.FullName;
import com.google.gdata.data.extensions.GivenName;
import com.google.gdata.data.extensions.Name;
import com.google.gdata.data.extensions.PhoneNumber;
import com.google.gdata.util.ServiceException;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AuthorizeContactList extends AppCompatActivity {

    public static RecyclerView recyclerView;
    public static TextView txtNoData;
    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private static List<AuthorizeSenderClass> data;
    public static DatabaseHandler db;
    FloatingActionButton add;
    public static Activity activity;
    Button btnImport, btnExport;
    ContactsService myService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authorize_contact_list);

        initialize();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),AuthorizeSender.class);
                startActivity(intent);
            }
        });

        btnImport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(data.size()>0) {
                    for(int i=0;i<data.size();i++) {
                        createContact(myService, data.get(i));
                    }
                }
            }
        });

        btnExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    printAllContacts(myService);
            }
        });

    }

    public void initialize() {
        activity = AuthorizeContactList.this;
        myService = new ContactsService("PushSMS");
        recyclerView = (RecyclerView) findViewById(R.id.recyclerview_authrize);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        db = new DatabaseHandler(this);
        add = (FloatingActionButton) findViewById(R.id.btnAddAuthorize);
        data = new ArrayList<AuthorizeSenderClass>();
        txtNoData = (TextView) findViewById(R.id.txtNoDataAuthorize);
        btnImport = (Button) findViewById(R.id.btnImportAuthorize);
        btnExport = (Button) findViewById(R.id.btnExportAuthorize);
    }

    public static void deleteItem(int pos) {
        db.deleteAuthContact(data.get(pos));
        data.remove(pos);
        adapter.notifyDataSetChanged();
        data = db.getAllAuthContacts();
        if(data.size()>0) {
            recyclerView.setVisibility(View.VISIBLE);
            txtNoData.setVisibility(View.GONE);
            adapter = new AuthorizeContactAdapter(activity, data);
            recyclerView.setAdapter(adapter);
        } else {
            recyclerView.setVisibility(View.GONE);
            txtNoData.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        data = db.getAllAuthContacts();
        Collections.reverse(data);
        if(data.size()>0) {
            recyclerView.setVisibility(View.VISIBLE);
            txtNoData.setVisibility(View.GONE);
            adapter = new AuthorizeContactAdapter(AuthorizeContactList.this, data);
            recyclerView.setAdapter(adapter);
        } else {
            recyclerView.setVisibility(View.GONE);
            txtNoData.setVisibility(View.VISIBLE);
        }
    }

    public static void createContact(final ContactsService myService, final AuthorizeSenderClass data) {
        /*// Create the entry to insert.
        ContactEntry contact = new ContactEntry();
        // Set the contact's name.
        Name name = new Name();
        final String NO_YOMI = null;
        name.setFullName(new FullName(data.getAuthsender(), NO_YOMI));
        name.setGivenName(new GivenName(String.valueOf(data.get_authid()), NO_YOMI));
        contact.setName(name);
        contact.setContent(new PlainTextConstruct(data.getAuthmessage()));
        // Set contact's phone numbers.
        PhoneNumber primaryPhoneNumber = new PhoneNumber();
        primaryPhoneNumber.setPhoneNumber(data.getAuthsender());
        primaryPhoneNumber.setPrimary(true);
        contact.addPhoneNumber(primaryPhoneNumber);

        // Ask the service to insert the new entry
        URL postUrl = null;
        ContactEntry createdContact = null;
        try {
            postUrl = new URL("http://www.google.com/m8/feeds/contacts/default/full");
            createdContact = myService.insert(postUrl, contact);
            System.out.println("Contact's ID: " + createdContact.getId());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ServiceException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return createdContact;*/



        class RetrieveFeedTask extends AsyncTask<Void, Void, Void> {

            private Exception exception;

            protected Void doInBackground(Void... str) {
                ContactEntry contact = new ContactEntry();
                // Set the contact's name.
                Name name = new Name();
                final String NO_YOMI = null;
                name.setFullName(new FullName(data.getAuthsender(), NO_YOMI));
                name.setGivenName(new GivenName(String.valueOf(data.get_authid()), NO_YOMI));
                contact.setName(name);
                contact.setContent(new PlainTextConstruct(data.getAuthmessage()));
                // Set contact's phone numbers.
                PhoneNumber primaryPhoneNumber = new PhoneNumber();
                primaryPhoneNumber.setPhoneNumber(data.getAuthsender());
                primaryPhoneNumber.setPrimary(true);
                contact.addPhoneNumber(primaryPhoneNumber);

                // Ask the service to insert the new entry
                URL postUrl = null;
                ContactEntry createdContact = null;
                try {
                    postUrl = new URL("https://www.google.com/m8/feeds/contacts/default/full");
                    createdContact = myService.insert(postUrl, contact);
                    System.out.println("Contact's ID: " + createdContact.getId());
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (ServiceException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        }

        new RetrieveFeedTask().execute();

    }

    public static void printAllContacts(final ContactsService myService) {
        /*// Request the feed
        URL feedUrl = new URL("http://www.google.com/m8/feeds/contacts/default/full");
        ContactFeed resultFeed = myService.getFeed(feedUrl, ContactFeed.class);
        // Print the results
        System.out.println(resultFeed.getTitle().getPlainText());
        for (ContactEntry entry : resultFeed.getEntries()) {
            if (entry.hasName()) {
                Name name = entry.getName();
                if (name.hasFullName()) {
                    String fullNameToDisplay = name.getFullName().getValue();
                    if (name.getFullName().hasYomi()) {
                        fullNameToDisplay += " (" + name.getFullName().getYomi() + ")";
                    }
                    System.out.println("\t\t" + fullNameToDisplay);
                } else {
                    System.out.println("\t\t (no full name found)");
                }
                if (name.hasGivenName()) {
                    String givenNameToDisplay = name.getGivenName().getValue();
                    if (name.getGivenName().hasYomi()) {
                        givenNameToDisplay += " (" + name.getGivenName().getYomi() + ")";
                    }
                    System.out.println("\t\t" + givenNameToDisplay);
                } else {
                    System.out.println("\t\t (no given name found)");
                }
            } else {
                System.out.println("\t (no name found)");
            }
            for (PhoneNumber number : entry.getPhoneNumbers()) {
                System.out.print(" " + number.getPhoneNumber());
                if (number.getPhoneNumber() != null) {
                    System.out.print(" Phone Number:" + number.getPhoneNumber());
                }
                System.out.print("\n");
            }

        }*/


        class RetrieveFeedTask extends AsyncTask<Void, Void, Void> {

            private Exception exception;

            protected Void doInBackground(Void... str) {
                // Request the feed
                URL feedUrl = null;
                try {
                    feedUrl = new URL("https://www.google.com/m8/feeds/contacts/default/full");
                    ContactFeed resultFeed = myService.getFeed(feedUrl, ContactFeed.class);
                    // Print the results
                    System.out.println(resultFeed.getTitle().getPlainText());
                    for (ContactEntry entry : resultFeed.getEntries()) {
                        if (entry.hasName()) {
                            Name name = entry.getName();
                            if (name.hasFullName()) {
                                String fullNameToDisplay = name.getFullName().getValue();
                                if (name.getFullName().hasYomi()) {
                                    fullNameToDisplay += " (" + name.getFullName().getYomi() + ")";
                                }
                                System.out.println("\t\t" + fullNameToDisplay);
                            } else {
                                System.out.println("\t\t (no full name found)");
                            }
                            if (name.hasGivenName()) {
                                String givenNameToDisplay = name.getGivenName().getValue();
                                if (name.getGivenName().hasYomi()) {
                                    givenNameToDisplay += " (" + name.getGivenName().getYomi() + ")";
                                }
                                System.out.println("\t\t" + givenNameToDisplay);
                            } else {
                                System.out.println("\t\t (no given name found)");
                            }
                        } else {
                            System.out.println("\t (no name found)");
                        }
                        for (PhoneNumber number : entry.getPhoneNumbers()) {
                            System.out.print(" " + number.getPhoneNumber());
                            if (number.getPhoneNumber() != null) {
                                System.out.print(" Phone Number:" + number.getPhoneNumber());
                            }
                            System.out.print("\n");
                        }
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (ServiceException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        }

        new RetrieveFeedTask().execute();

    }

}
