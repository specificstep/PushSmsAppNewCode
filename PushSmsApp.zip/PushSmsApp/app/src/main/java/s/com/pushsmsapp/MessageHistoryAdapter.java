package s.com.pushsmsapp;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class MessageHistoryAdapter extends RecyclerView.Adapter<MessageHistoryAdapter.MyViewHolder> {

    private List<MesaageHistory> dataSet;
    DatabaseHandler db;
    Context context;

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txtSender;
        TextView txtMsg;
        TextView txtStatus;
        Button delete;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.txtSender = (TextView) itemView.findViewById(R.id.txtHistorySender);
            this.txtMsg = (TextView) itemView.findViewById(R.id.txtHistoryMsg);
            this.delete = (Button) itemView.findViewById(R.id.btnDeleteHistory);
            this.txtStatus = (TextView) itemView.findViewById(R.id.txtHistoryStatus);
        }
    }

    public MessageHistoryAdapter(Context context, List<MesaageHistory> data) {
        this.context = context;
        this.dataSet = data;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent,
                                           int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_message_history, parent, false);

        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int listPosition) {

        holder.txtSender.setText(dataSet.get(listPosition).getSender());
        holder.txtMsg.setText(URLDecoder.decode(dataSet.get(listPosition).getMessage()));
        holder.txtStatus.setText("Status: " + dataSet.get(listPosition).getStatus());

        db = new DatabaseHandler(context);
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MessageHistoryActivity.deleteItem(listPosition);
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

}
