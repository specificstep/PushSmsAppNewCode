package s.com.pushsmsapp;

import android.app.Activity;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class MessageHistoryActivity extends AppCompatActivity {

    public static RecyclerView recyclerView;
    public static TextView txtNoData;
    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private static List<MesaageHistory> data;
    public static DatabaseHandler db;
    public static Activity activity;
    SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_history);

        initialize();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                data = db.getAllContacts();
                Collections.reverse(data);
                if(data.size()>0) {
                    recyclerView.setVisibility(View.VISIBLE);
                    txtNoData.setVisibility(View.GONE);
                    adapter = new MessageHistoryAdapter(MessageHistoryActivity.this, data);
                    recyclerView.setAdapter(adapter);
                } else {
                    recyclerView.setVisibility(View.GONE);
                    txtNoData.setVisibility(View.VISIBLE);
                }
                swipeRefreshLayout.setRefreshing(false);
            }
        });

    }

    public void initialize() {

        activity = MessageHistoryActivity.this;
        recyclerView = (RecyclerView) findViewById(R.id.recyclerview_history);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        db = new DatabaseHandler(this);

        data = new ArrayList<MesaageHistory>();
        txtNoData = (TextView) findViewById(R.id.txtNoDataHistory);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.pullToRefresh);

    }

    public static void deleteItem(int pos) {
        db.deleteContact(data.get(pos));
        data.remove(pos);
        adapter.notifyDataSetChanged();
        data = db.getAllContacts();
        Collections.reverse(data);
        if(data.size()>0) {
            recyclerView.setVisibility(View.VISIBLE);
            txtNoData.setVisibility(View.GONE);
            adapter = new MessageHistoryAdapter(activity, data);
            recyclerView.setAdapter(adapter);
        } else {
            recyclerView.setVisibility(View.GONE);
            txtNoData.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        data = db.getAllContacts();
        Collections.reverse(data);
        if(data.size()>0) {
            recyclerView.setVisibility(View.VISIBLE);
            txtNoData.setVisibility(View.GONE);
            adapter = new MessageHistoryAdapter(MessageHistoryActivity.this, data);
            recyclerView.setAdapter(adapter);
        } else {
            recyclerView.setVisibility(View.GONE);
            txtNoData.setVisibility(View.VISIBLE);
        }
    }

}
