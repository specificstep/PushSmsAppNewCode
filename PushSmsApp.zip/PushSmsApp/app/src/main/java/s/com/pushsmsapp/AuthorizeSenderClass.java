package s.com.pushsmsapp;

public class AuthorizeSenderClass {

    int _authid;
    String authsender;
    String authmessage;

    public AuthorizeSenderClass() {
    }

    public AuthorizeSenderClass(String authsender, String authmessage) {
        this.authsender = authsender;
        this.authmessage = authmessage;
    }

    public AuthorizeSenderClass(int _authid, String authsender, String authmessage) {
        this._authid = _authid;
        this.authsender = authsender;
        this.authmessage = authmessage;
    }

    public int get_authid() {
        return _authid;
    }

    public void set_authid(int _authid) {
        this._authid = _authid;
    }

    public String getAuthsender() {
        return authsender;
    }

    public void setAuthsender(String authsender) {
        this.authsender = authsender;
    }

    public String getAuthmessage() {
        return authmessage;
    }

    public void setAuthmessage(String authmessage) {
        this.authmessage = authmessage;
    }
}
