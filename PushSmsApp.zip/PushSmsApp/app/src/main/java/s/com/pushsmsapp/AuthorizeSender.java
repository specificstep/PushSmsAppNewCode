package s.com.pushsmsapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AuthorizeSender extends AppCompatActivity {

    EditText edtSender, edtMsg;
    TextView submit;
    DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authorize_sender);

        edtSender = (EditText) findViewById(R.id.auth_sender);
        edtMsg = (EditText) findViewById(R.id.auth_msg);
        submit = (TextView) findViewById(R.id.auth_submit);
        db = new DatabaseHandler(this);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(varify()) {
                    db.addAuthContact(new AuthorizeSenderClass(edtSender.getText().toString(),edtMsg.getText().toString()));
                    MainActivity.number = edtSender.getText().toString();
                    MainActivity.msg = edtMsg.getText().toString();
                    AuthorizeSender.this.finish();
                }
            }
        });

    }

    public boolean varify() {
        if(TextUtils.isEmpty(edtSender.getText().toString())) {
            Toast.makeText(getApplicationContext(),"Enter Sender",Toast.LENGTH_LONG).show();
            return false;
        }/* else if(TextUtils.isEmpty(edtMsg.getText().toString())) {
            Toast.makeText(getApplicationContext(),"Enter Message",Toast.LENGTH_LONG).show();
            return false;
        }*/ else {
            return true;
        }
    }

}
